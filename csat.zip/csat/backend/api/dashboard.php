<?php
// /var/www/html/csat/backend/api/dashboard.php
require_once 'db.php';

try {
    // 1. Get Total Scans ever run
    $stmtScans = $pdo->query("SELECT COUNT(*) as total FROM scan_requests");
    $total_scans = (int)$stmtScans->fetch()['total'];

    // Dynamically count threats using a JOIN for 3NF
    $stmtThreats = $pdo->query("
        SELECT 
            COUNT(*) as total_vulnerabilities,
            SUM(CASE WHEN v.severity = 'CRITICAL' THEN 1 ELSE 0 END) as critical_count,
            SUM(CASE WHEN v.severity = 'HIGH' THEN 1 ELSE 0 END) as high_count,
            SUM(CASE WHEN v.severity = 'MEDIUM' THEN 1 ELSE 0 END) as medium_count,
            SUM(CASE WHEN v.severity = 'LOW' THEN 1 ELSE 0 END) as low_count
        FROM scan_results sr
        JOIN vulnerabilities v ON sr.vulnerability_id = v.vulnerability_id
    ");
    $threats = $stmtThreats->fetch();

    // 3. Check how many distinct scans happened recently (Scans this week)
    $stmtWeek = $pdo->query("SELECT COUNT(DISTINCT scan_id) as weekly FROM scan_results WHERE found_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $scans_this_week = (int)$stmtWeek->fetch()['weekly'];
    
    // Fallback: If there are scans but no results yet, just show total_scans
    if ($scans_this_week == 0 && $total_scans > 0) {
         $scans_this_week = $total_scans; 
    }

    // 4. Get Open Alerts (from your alerts table)
    $stmtAlerts = $pdo->query("SELECT COUNT(*) as open_alerts FROM alerts WHERE acknowledged = 0");
    $open_alerts = (int)$stmtAlerts->fetch()['open_alerts'];

    // Send everything to your JavaScript frontend!
    echo json_encode([
        'success' => true,
        'total_scans' => $total_scans,
        'critical_count' => (int)$threats['critical_count'],
        'high_count' => (int)$threats['high_count'],
        'medium_count' => (int)$threats['medium_count'],
        'low_count' => (int)$threats['low_count'],
        'total_vulnerabilities' => (int)$threats['total_vulnerabilities'],
        'scans_this_week' => $scans_this_week, 
        'open_alerts' => $open_alerts
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>