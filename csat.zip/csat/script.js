// ============================================================
// CSAT — Cyber Security Assessment Tool
// Frontend ↔ PHP Backend Connection
// ============================================================

// API Base URL Configuration

// Development: http://localhost/csat/backend/api
const API_BASE = 'http://localhost/csat/backend/api';

// Global application state
let currentUser = null;           // Authenticated user object: { id, username, role }
let currentScanData = [];          // Current scan results for export/display

// ============================================================
// 1. Navigation and View Management
// ============================================================
function switchView(viewName) {
    document.querySelectorAll('.app-view').forEach(el => {
        el.classList.remove('d-block');
        el.classList.add('d-none');
    });
    document.querySelectorAll('.nav-link').forEach(el => el.classList.remove('active'));
    const nextView = document.getElementById('view-' + viewName);
    nextView.classList.remove('d-none');
    nextView.classList.add('d-block');
    document.getElementById('nav-' + viewName).classList.add('active');

    // Fetch SIEM logs when admin panel is accessed
    if (viewName === 'admin') fetchSiemLogs();
}

// ============================================================
// 2. Dashboard Statistics
// Fetches real-time threat and vulnerability metrics from database
// ============================================================
async function loadDashboard() {
    try {
        const res  = await fetch(`${API_BASE}/dashboard.php`);
        const data = await res.json();
        if (data.success) {
            // Populate dashboard statistics
            document.getElementById('stat-total-scans').textContent = data.total_scans;
            document.getElementById('stat-critical').textContent = data.critical_count;
            document.getElementById('stat-high').textContent = data.high_count;
            document.getElementById('stat-medium').textContent = data.medium_count;
            document.getElementById('stat-low').textContent = data.low_count;
            document.getElementById('stat-vulnerabilities').textContent = data.total_vulnerabilities;
            document.getElementById('stat-week').textContent = data.scans_this_week;
            document.getElementById('stat-alerts').textContent = data.open_alerts;
        }
    } catch (err) {
        console.error('Error loading dashboard statistics:', err);
    }
}

// ============================================================
// 3. URL and IP Address Scanner
// Performs security scans using multiple threat intelligence APIs
// ============================================================
document.getElementById('urlScanForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const target  = document.getElementById('urlInput').value.trim();
    const btn     = document.getElementById('urlBtn');

    // Collect selected data sources for scanning
    const sources = ['virustotal', 'abuseipdb']
        .filter(id => document.getElementById('chk-' + id)?.checked)
        .map(id => document.getElementById('chk-' + id).value);

    if (sources.length === 0) {
        alert('Please select at least one scan source.');
        return;
    }

    btn.textContent = 'Scanning...';
    btn.disabled    = true;

    try {
        const res  = await fetch(`${API_BASE}/scan_url.php`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({
                target:  target,
                sources: sources,
                user_id: currentUser?.id ?? null,
            }),
        });
        const data = await res.json();

        if (data.success) {
            currentScanData = data.results;
            populateResultsTable(currentScanData);
            loadDashboard();
            switchView('results');
            document.getElementById('urlInput').value = '';
        } else {
            alert('Scan failed: ' + (data.error || 'Unknown error'));
        }
    } catch (err) {
        alert('Connection error. Please verify the backend server is running. Details: ' + err.message);
        console.error('URL scan error:', err);
    } finally {
        btn.textContent = 'Scan Target';
        btn.disabled    = false;
    }
});

// ============================================================
// 4. Domain and Subdomain Discovery
// Discovers associated domains and subdomains using OSINT sources
// ============================================================
document.getElementById('domainScanForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const target  = document.getElementById('domainInput').value.trim();
    const btn     = document.getElementById('domainBtn');

    // Collect selected discovery sources
    const sources = ['shodan', 'dns']
        .filter(id => document.getElementById('chk-' + id)?.checked)
        .map(id => document.getElementById('chk-' + id).value);

    if (sources.length === 0) {
        alert('Please select at least one discovery method.');
        return;
    }

    btn.textContent = 'Querying...';
    btn.disabled    = true;

    try {
        const res  = await fetch(`${API_BASE}/scan_domain.php`, {
            method:  'POST',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({
                target:  target,
                sources: sources,
                user_id: currentUser?.id ?? null,
            }),
        });
        const data = await res.json();

        if (data.success) {
            currentScanData = data.results;
            populateResultsTable(currentScanData);
            loadDashboard();
            switchView('results');
            document.getElementById('domainInput').value = '';
        } else {
            alert('Domain discovery failed: ' + (data.error || 'Unknown error'));
        }
    } catch (err) {
        alert('Connection error: ' + err.message);
        console.error('Domain scan error:', err);
    } finally {
        btn.textContent = 'Discover Subdomains';
        btn.disabled    = false;
    }
});

// ============================================================
// 5. Results Table Population
// Renders scan results with proper security escaping
// ============================================================
// =============================================
// 5. Results Table
// =============================================
function populateResultsTable(data) {
    const tbody = document.getElementById('results-table-body');
    tbody.innerHTML = '';

    if (!data || data.length === 0) {
        // Updated colspan from 5 to 6 to match new Actions column
        tbody.innerHTML = '<tr><td colspan="6" class="text-center py-4 text-muted">No results found.</td></tr>';
        return;
    }

    // Added 'index' so the button knows which row was clicked
    data.forEach((item, index) => {
        let badge = 'bg-secondary';
        if (item.severity === 'CRITICAL')    badge = 'bg-danger';
        else if (item.severity === 'HIGH')   badge = 'bg-warning text-dark';
        else if (item.severity === 'MEDIUM') badge = 'bg-primary';

        tbody.innerHTML += `
            <tr>
                <td><strong>${escHtml(item.target)}</strong></td>
                <td>${escHtml(item.type)}</td>
                <td><span class="badge bg-dark">${escHtml(item.source)}</span></td>
                <td><span class="badge ${badge}">${escHtml(item.severity)}</span></td>
                <td>${escHtml(item.details)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-info fw-bold" onclick="viewDetails(${index})">
                        👁️ View Report
                    </button>
                </td>
            </tr>`;
    });
}

// =============================================
// 5.5 Detailed Report Modal Logic
// =============================================
function viewDetails(index) {
    const item = currentScanData[index];
    const modalBody = document.getElementById('reportModalBody');
    
    let badge = 'bg-secondary';
    if (item.severity === 'CRITICAL')    badge = 'bg-danger';
    else if (item.severity === 'HIGH')   badge = 'bg-warning text-dark';
    else if (item.severity === 'MEDIUM') badge = 'bg-primary';

    // AI Feature: Generate specific patterns and remediation based on the API Source
    let patterns = "";
    let remediation = "";

    if (item.source === 'VirusTotal') {
        patterns = `
            <li><strong>Malware Signatures:</strong> Matched against known threat actor hash databases.</li>
            <li><strong>Historical Behavior:</strong> Target has previously hosted malicious payloads, trojans, or phishing kits.</li>
        `;
        remediation = "Quarantine any internal endpoints communicating with this IP/URL. Blacklist immediately on the perimeter firewall.";
    } else if (item.source === 'AbuseIPDB') {
        patterns = `
            <li><strong>Crowdsourced Abuse:</strong> High volume of reports from global network administrators.</li>
            <li><strong>Attack Type:</strong> Likely associated with automated Port Scanning, SSH Brute-Forcing, or DDoS botnets.</li>
        `;
        remediation = "Add to dynamic firewall blocklist for 30-90 days. Monitor SIEM logs for lateral movement attempts.";
    } else {
        patterns = `<li><strong>OSINT Match:</strong> Associated threat footprint discovered in public reconnaissance databases.</li>`;
        remediation = "Review related domains and block if deemed unauthorized or risky.";
    }

    // Build the beautiful dark-themed HTML report
    modalBody.innerHTML = `
        <div class="card bg-secondary text-white mb-4 border-0 shadow-sm">
            <div class="card-body row">
                <div class="col-md-6 mb-2"><strong>Target ID:</strong> <span class="text-info">${escHtml(item.target)}</span></div>
                <div class="col-md-6 mb-2"><strong>API Source:</strong> ${escHtml(item.source)}</div>
                <div class="col-md-6 mb-2"><strong>Severity Level:</strong> <span class="badge ${badge} fs-6">${escHtml(item.severity)}</span></div>
                <div class="col-md-6 mb-2"><strong>Time of Scan:</strong> ${new Date().toLocaleString()}</div>
            </div>
        </div>
        
        <h6 class="text-info border-bottom border-secondary pb-2 mb-3">🔍 Initial Finding Details</h6>
        <p class="mb-4 text-light">${escHtml(item.details)}</p>

        <h6 class="text-warning border-bottom border-secondary pb-2 mb-3">⚠️ Detected Threat Patterns</h6>
        <ul class="mb-4 text-light">
            ${patterns}
        </ul>

        <h6 class="text-success border-bottom border-secondary pb-2 mb-3">🛡️ Recommended Analyst Action (Playbook)</h6>
        <p class="text-light">${remediation}</p>
    `;

    // Trigger the Bootstrap Modal
    const reportModal = new bootstrap.Modal(document.getElementById('reportModal'));
    reportModal.show();
}

// HTML escape function to prevent XSS attacks
function escHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

// ============================================================
// 6. Password Strength Analyzer
// Evaluates password complexity and provides real-time feedback
// ============================================================
let passwordVisible = true;

function togglePassword() {
    const input = document.getElementById('passwordInput');
    const btn   = document.getElementById('togglePasswordVisibility');
    passwordVisible = !passwordVisible;
    input.type  = passwordVisible ? 'text' : 'password';
    btn.textContent = passwordVisible ? '👁️ Hide' : '👁️ Show';
}

document.getElementById('passwordInput').addEventListener('input', function() {
    const pw          = this.value;
    const progressBar = document.getElementById('password-progress');
    const feedback    = document.getElementById('password-feedback');

    if (pw.length === 0) {
        progressBar.style.width = '0%';
        feedback.innerText = '';
        return;
    }

    // Calculate strength score: 0-100
    let strength = 0;
    if (pw.length >= 8)            strength += 25;
    if (pw.match(/[A-Z]/))         strength += 25;
    if (pw.match(/[0-9]/))         strength += 25;
    if (pw.match(/[^a-zA-Z0-9]/)) strength += 25;

    progressBar.style.width = strength + '%';
    progressBar.className   = 'progress-bar';

    if (strength <= 25) {
        progressBar.classList.add('bg-danger');
        feedback.innerText    = 'Weak: Add uppercase letters, numbers, and symbols.';
        feedback.className    = 'text-danger fw-bold mt-2';
    } else if (strength === 50) {
        progressBar.classList.add('bg-warning');
        feedback.innerText    = 'Fair: Include special characters and numbers.';
        feedback.className    = 'text-warning fw-bold mt-2';
    } else if (strength === 75) {
        progressBar.classList.add('bg-info');
        feedback.innerText    = 'Good: Almost there. Consider adding more variety.';
        feedback.className    = 'text-info fw-bold mt-2';
    } else {
        progressBar.classList.add('bg-success');
        feedback.innerText    = 'Strong: Excellent password strength.';
        feedback.className    = 'text-success fw-bold mt-2';
    }
});

// ============================================================
// 7. SIEM System Logs Retrieval
// Displays security event logs from database in real-time
// ============================================================
async function fetchSiemLogs() {
    const logList = document.getElementById('siem-logs');
    logList.innerHTML = '<li class="list-group-item text-muted">Loading system logs...</li>';

    try {
        const res  = await fetch(`${API_BASE}/siem_logs.php?limit=20`);
        const data = await res.json();

        if (data.success && data.logs.length > 0) {
            logList.innerHTML = '';
            data.logs.forEach(log => {
                const li  = document.createElement('li');
                li.className = 'list-group-item';
                if (log.severity === 'CRITICAL' || log.severity === 'HIGH') li.classList.add('text-danger');
                else if (log.severity === 'MEDIUM') li.classList.add('text-warning');
                else if (log.status === 'FAILURE') li.classList.add('text-danger');

                const time = new Date(log.timestamp).toLocaleTimeString();
                const user = log.username ? ` [${log.username}]` : '';
                li.textContent = `[${time}]${user} ${log.action} — ${log.status}`;
                logList.appendChild(li);
            });
        } else {
            logList.innerHTML = '<li class="list-group-item text-muted">No logs available.</li>';
        }
    } catch (err) {
        logList.innerHTML = '<li class="list-group-item text-danger">Failed to load logs. Please verify the backend service.</li>';
        console.error('SIEM logs error:', err);
    }
}

// ============================================================
// 8. CSV Export Functionality
// Exports current scan results in CSV format for reporting
// ============================================================
function downloadCSV() {
    if (currentScanData.length === 0) {
        alert('Please run a scan before exporting results.');
        return;
    }

    let csv = 'Target,Type,API Source,Severity,Finding Details\n';
    currentScanData.forEach(row => {
        csv += `${row.target},${row.type},${row.source},${row.severity},"${row.details}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href     = URL.createObjectURL(blob);
    link.download = 'CSAT_Scan_Results.csv';
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// ============================================================
// Application Initialization
// Load dashboard statistics on page load
// ============================================================
loadDashboard();
