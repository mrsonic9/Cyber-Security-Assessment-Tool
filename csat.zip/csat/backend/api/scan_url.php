<?php
// scan_url.php
require_once 'db.php';

// Get JSON input from frontend fetch request
$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE);

if (!$input || empty($input['target'])) {
    echo json_encode(['success' => false, 'error' => 'No target provided']);
    exit;
}

$target = $input['target'];
$sources = $input['sources'] ?? [];
$results = [];

// 1. VirusTotal Integration
if (in_array('VirusTotal', $sources)) {
    // INSERT YOUR VIRUSTOTAL API KEY HERE
    $vt_key = 'INSERT YOUR VIRUSTOTAL API KEY HERE'; 
    
    $ch = curl_init();
    
    // VirusTotal handles IPs and URLs differently. We check which one the user entered.
    if (filter_var($target, FILTER_VALIDATE_IP)) {
        // If it is an IP Address
        $vt_url = "https://www.virustotal.com/api/v3/ip_addresses/" . $target;
    } else {
        // If it is a URL or Domain, VT requires it to be base64url encoded
        $url_id = rtrim(strtr(base64_encode($target), '+/', '-_'), '=');
        $vt_url = "https://www.virustotal.com/api/v3/urls/" . $url_id;
    }
    
    curl_setopt($ch, CURLOPT_URL, $vt_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // Notice that VirusTotal uses 'x-apikey' instead of 'Key'
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "x-apikey: $vt_key",
        "accept: application/json"
    ]);
    
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpcode == 200 && $response) {
        $data = json_decode($response, true);
        
        // Extract the stats from the VT response
        $stats = $data['data']['attributes']['last_analysis_stats'];
        $malicious = $stats['malicious'] ?? 0;
        $suspicious = $stats['suspicious'] ?? 0;
        $harmless = $stats['harmless'] ?? 0;
        
        // Calculate Severity
        $severity = 'LOW';
        if ($malicious > 5) {
            $severity = 'CRITICAL';
        } elseif ($malicious > 0 || $suspicious > 2) {
            $severity = 'HIGH';
        } elseif ($suspicious > 0) {
            $severity = 'MEDIUM';
        }

        $details = "Malicious: $malicious | Suspicious: $suspicious | Clean: $harmless";

        $results[] = [
            'target' => $target, 'type' => filter_var($target, FILTER_VALIDATE_IP) ? 'IP' : 'URL', 
            'source' => 'VirusTotal', 'severity' => $severity, 'details' => $details,
            'raw_data' => $data
        ];
    } else {
        // If VT returns an error (like 404 if the URL was never scanned before)
        $error_msg = 'Not found in VT database, or connection failed.';
        if ($response) {
            $err_data = json_decode($response, true);
            if (isset($err_data['error']['message'])) {
                $error_msg = $err_data['error']['message'];
            }
        }
        $results[] = [
            'target' => $target, 'type' => 'URL/IP', 'source' => 'VirusTotal',
            'severity' => 'INFO', 'details' => $error_msg
        ];
    }
}

// 2. AbuseIPDB Integration
if (in_array('AbuseIPDB', $sources)) {
    // INSERT YOUR ABUSEIPDB API KEY HERE
    $abuse_key = 'INSERT YOUR ABUSEIPDB API KEY HERE';
    
    $ch = curl_init();
    $url = "https://api.abuseipdb.com/api/v2/check?ipAddress=" . urlencode($target) . "&maxAgeInDays=90";
    
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Key: $abuse_key",
        "Accept: application/json"
    ]);
    
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpcode == 200 && $response) {
        $data = json_decode($response, true);
        $score = $data['data']['abuseConfidenceScore'];
        
        // Determine severity based on score
        $severity = 'LOW';
        if ($score > 80) $severity = 'CRITICAL';
        elseif ($score > 50) $severity = 'HIGH';
        elseif ($score > 20) $severity = 'MEDIUM';

        $details = "Confidence Score: $score%. Total Reports: " . $data['data']['totalReports'];

        $results[] = [
            'target' => $target, 'type' => 'IP', 'source' => 'AbuseIPDB',
            'severity' => $severity, 'details' => $details,
            'raw_data' => $data
        ];
    } else {
        $results[] = [
            'target' => $target, 'type' => 'IP', 'source' => 'AbuseIPDB',
            'severity' => 'INFO', 'details' => 'Failed to connect or invalid IP format.'
        ];
    }
}

// Database Logging, Alerting, API Usage, Risk Scores, and Reports (3NF)
try {
    // 1. Create the main scan request
    $stmt = $pdo->prepare("INSERT INTO scan_requests (user_id, target, scan_type, status) VALUES (1, ?, 'url_scan', 'completed')");
    $stmt->execute([$target]);
    $scan_id = $pdo->lastInsertId();

    $counts = ['CRITICAL' => 0, 'HIGH' => 0, 'MEDIUM' => 0, 'LOW' => 0, 'INFO' => 0];

    // Prepare 3NF Statements and API Tracker
    $stmt_vuln = $pdo->prepare("INSERT INTO vulnerabilities (name, severity, description) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE vulnerability_id=LAST_INSERT_ID(vulnerability_id), description=VALUES(description)");
    $stmt_result = $pdo->prepare("INSERT INTO scan_results (scan_id, vulnerability_id, api_source) VALUES (?, ?, ?)");
    $stmt_payload = $pdo->prepare("INSERT INTO siem_log_payloads (log_id, payload_key, payload_value) VALUES (?, ?, ?)");
    $stmt_api = $pdo->prepare("INSERT INTO api_usage (api_name, request_date, request_count, daily_limit, last_called_at) VALUES (?, CURDATE(), 1, 1000, NOW()) ON DUPLICATE KEY UPDATE request_count = request_count + 1, last_called_at = NOW()");

    foreach ($results as $res) {
        $source = $res['source'];
        $severity = $res['severity'];
        $vuln_name = "Threat Intelligence: " . $res['type'];
        $description = $res['details'];
        $counts[$severity]++; 
        
        // Step A: Save to dictionary and get ID
        $stmt_vuln->execute([$vuln_name, $severity, $description]);
        $vulnerability_id = $pdo->lastInsertId();

        // Step B: Save to scan_results
        $stmt_result->execute([$scan_id, $vulnerability_id, $source]);

        // Track API Usage
        if ($source === 'VirusTotal' || $source === 'AbuseIPDB') {
            $stmt_api->execute([$source]);
        }

        // Trigger Alert and Payload logging for High/Critical Threats
        if ($severity === 'CRITICAL' || $severity === 'HIGH') {
            $stmt_log = $pdo->prepare("INSERT INTO siem_logs (event_type, severity, user_id, target, action, status) VALUES ('THREAT_DETECTED', ?, 1, ?, ?, 'SUCCESS')");
            $stmt_log->execute([$severity, $target, "Detected $severity threat via $source"]);
            $log_id = $pdo->lastInsertId();

            // Step C: Save data to your new payload table!
            $stmt_payload->execute([$log_id, 'api_source', $source]);
            $stmt_payload->execute([$log_id, 'target_ip', $target]);

            $stmt_alert = $pdo->prepare("INSERT INTO alerts (rule_name, triggered_by_log_id, acknowledged) VALUES (?, ?, 0)");
            $stmt_alert->execute(["$severity Threat Found on $target", $log_id]);
        }
    }

    // Risk Score & Reports
    $score = ($counts['CRITICAL'] * 25) + ($counts['HIGH'] * 15) + ($counts['MEDIUM'] * 5) + ($counts['LOW'] * 1);
    $score = min($score, 100); 
    $stmt_risk = $pdo->prepare("INSERT INTO risk_scores (scan_id, score, critical_count, high_count, medium_count, low_count, info_count) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt_risk->execute([$scan_id, $score, $counts['CRITICAL'], $counts['HIGH'], $counts['MEDIUM'], $counts['LOW'], $counts['INFO']]);

    $clean_target = preg_replace('/[^A-Za-z0-9_\-]/', '_', $target);
    $stmt_report = $pdo->prepare("INSERT INTO reports (scan_id, user_id, file_name) VALUES (?, 1, ?)");
    $stmt_report->execute([$scan_id, "CSAT_Report_" . $clean_target . "_" . time() . ".csv"]);

} catch (Exception $e) { 
    // Ignore database errors to keep UI alive
}

echo json_encode(['success' => true, 'results' => $results]);
?>
