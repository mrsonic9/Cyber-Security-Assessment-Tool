<?php
// scan_domain.php
require_once 'db.php';

$inputJSON = file_get_contents('php://input');
$input = json_decode($inputJSON, TRUE);

if (!$input || empty($input['target'])) {
    echo json_encode(['success' => false, 'error' => 'No domain provided']);
    exit;
}

$target = $input['target'];
$sources = $input['sources'] ?? [];
$results = [];

// Native PHP DNS Lookup (Free, no API required)
if (in_array('DNS Lookup', $sources)) {
    $dns_records = dns_get_record($target, DNS_A);
    $ip_list = array_column($dns_records, 'ip');
    $details = !empty($ip_list) ? "Resolved IPs: " . implode(", ", $ip_list) : "No A records found.";
    
    $results[] = [
        'target' => $target, 'type' => 'Domain', 'source' => 'DNS Lookup',
        'severity' => 'INFO', 'details' => $details
    ];
}

// Shodan Integration
if (in_array('Shodan', $sources)) {
    // INSERT YOUR SHODAN API KEY HERE
    $shodan_key = ' INSERT YOUR SHODAN API KEY HERE';
    
    // Shodan DNS domain lookup endpoint
    $shodan_url = "https://api.shodan.io/dns/domain/" . urlencode($target) . "?key=" . $shodan_key;
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $shodan_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpcode == 200 && $response) {
        $data = json_decode($response, true);
        
        // Shodan returns subdomains in an array
        $subdomains_count = isset($data['data']) ? count($data['data']) : 0;
        
        $results[] = [
            'target' => $target, 'type' => 'Domain', 'source' => 'Shodan',
            'severity' => 'INFO', 'details' => "Found $subdomains_count associated subdomains/records."
        ];
    } else {
        $results[] = [
            'target' => $target, 'type' => 'Domain', 'source' => 'Shodan',
            'severity' => 'INFO', 'details' => 'Could not retrieve data (check API key or limit).'
        ];
    }
}

// Database Logging, Alerting, API Usage, Risk Scores, and Reports (3NF)
try {
    // 1. Create the main scan request
    $stmt = $pdo->prepare("INSERT INTO scan_requests (user_id, target, scan_type, status) VALUES (1, ?, 'domain_scan', 'completed')");
    $stmt->execute([$target]);
    $scan_id = $pdo->lastInsertId();

    $counts = ['CRITICAL' => 0, 'HIGH' => 0, 'MEDIUM' => 0, 'LOW' => 0, 'INFO' => 0];

    // Prepare 3NF Statements and API Tracker
    $stmt_vuln = $pdo->prepare("INSERT INTO vulnerabilities (name, severity, description) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE vulnerability_id=LAST_INSERT_ID(vulnerability_id), description=VALUES(description)");
    $stmt_result = $pdo->prepare("INSERT INTO scan_results (scan_id, vulnerability_id, api_source) VALUES (?, ?, ?)");
    $stmt_payload = $pdo->prepare("INSERT INTO siem_log_payloads (log_id, payload_key, payload_value) VALUES (?, ?, ?)");
    $stmt_api = $pdo->prepare("INSERT INTO api_usage (api_name, request_date, request_count, daily_limit, last_called_at) VALUES (?, CURDATE(), 1, 1000, NOW()) ON DUPLICATE KEY UPDATE request_count = request_count + 1, last_called_at = NOW()");

    foreach ($results as $res) {
        $source = $res['source'];
        $severity = $res['severity'];
        $vuln_name = "OSINT Discovery: " . $res['type'];
        $description = $res['details'];
        $counts[$severity]++; 
        
        // Step A: Save to dictionary and get ID
        $stmt_vuln->execute([$vuln_name, $severity, $description]);
        $vulnerability_id = $pdo->lastInsertId();

        // Step B: Save to scan_results
        $stmt_result->execute([$scan_id, $vulnerability_id, $source]);

        // Track API Usage for Shodan
        if ($source === 'Shodan') {
            $stmt_api->execute([$source]);
        }

        // Trigger Alert and Payload logging for High/Critical Threats
        if ($severity === 'CRITICAL' || $severity === 'HIGH') {
            $stmt_log = $pdo->prepare("INSERT INTO siem_logs (event_type, severity, user_id, target, action, status) VALUES ('THREAT_DETECTED', ?, 1, ?, ?, 'SUCCESS')");
            $stmt_log->execute([$severity, $target, "Detected $severity risk via $source"]);
            $log_id = $pdo->lastInsertId();

            // Step C: Save data to your new payload table!
            $stmt_payload->execute([$log_id, 'api_source', $source]);
            $stmt_payload->execute([$log_id, 'target_domain', $target]);

            $stmt_alert = $pdo->prepare("INSERT INTO alerts (rule_name, triggered_by_log_id, acknowledged) VALUES (?, ?, 0)");
            $stmt_alert->execute(["$severity OSINT Risk Found on $target", $log_id]);
        }
    }

    // Risk Score & Reports
    $score = ($counts['CRITICAL'] * 25) + ($counts['HIGH'] * 15) + ($counts['MEDIUM'] * 5) + ($counts['LOW'] * 1);
    $score = min($score, 100); 
    $stmt_risk = $pdo->prepare("INSERT INTO risk_scores (scan_id, score, critical_count, high_count, medium_count, low_count, info_count) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt_risk->execute([$scan_id, $score, $counts['CRITICAL'], $counts['HIGH'], $counts['MEDIUM'], $counts['LOW'], $counts['INFO']]);

    $clean_target = preg_replace('/[^A-Za-z0-9_\-]/', '_', $target);
    $stmt_report = $pdo->prepare("INSERT INTO reports (scan_id, user_id, file_name) VALUES (?, 1, ?)");
    $stmt_report->execute([$scan_id, "CSAT_Report_" . $clean_target . "_" . time() . ".csv"]);

} catch (Exception $e) { 
    // Ignore database errors to keep UI alive
}

echo json_encode(['success' => true, 'results' => $results]);
?>
