<?php
// siem_logs.php
require_once 'db.php';

try {
    $stmt = $pdo->query("SELECT event_type, severity, action, status, timestamp, u.username 
                         FROM siem_logs s 
                         LEFT JOIN users u ON s.user_id = u.id 
                         ORDER BY timestamp DESC LIMIT 20");
    $logs = $stmt->fetchAll();

    echo json_encode(['success' => true, 'logs' => $logs]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>