<?php echo 'PHP OK: '.phpversion(); ?>
 